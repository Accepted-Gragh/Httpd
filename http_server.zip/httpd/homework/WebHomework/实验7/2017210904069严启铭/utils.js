module.exports = {
  log: (message) => {
    console && console.log(message)
  }
}
