/**
 *
 * @authors ZFXG
 * @date    2020-03-12 15:55:11
 * @version $Id$
 */
let list = document.querySelectorAll('.m-item');
let box = document.querySelector('.m-box');


//li元素点击响应
box.addEventListener("click", e => {
	if (e.target && e.target.nodeName == "LI") {
		for (let i = 0, len = list.length; i < len; i++)
			if (e.target === list[i])
				alert("序号为：" + i);
	}
});

window.onload = function() {
	list[0].onclick = function() {
		this.style.color = "red";
	}
	list[1].onclick = function() {
		var date = new Date();
		var datestr = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
		box.childNodes[1].innerHTML = datestr;
	}
	list[2].onclick = function() {
		list[2].classList.add("fn-active");
	}
	list[3].onclick = function() {
		list[3].parentNode.removeChild(list[7]);
	}
	list[4].onclick = function() {
		window.open("https://www.taobao.com/");
	}
	list[5].onclick = function() {
		var newlist = document.createElement('li');
		var node = document.createTextNode('p9');
		newlist.appendChild(node);
		newlist.classList.add('m-item');
		list[5].parentNode.appendChild(newlist);
	}
}