/**
 * 
 * @authors Your Name (you@example.org)
 * @date    2020-03-12 15:11:11
 * @version $Id$
 */

p1.onclick = function() {
	alert("p1");
    this.style.color = "red";
    
}


p2.onclick = function() {
   var h1 = document.getElementsByTagName("h1")[0];
   var d = new Date();
   var month = d.getMonth()+1;
   var day = d.getDate();
    if(month>=1 && month<=9)
   	  month = "0"+ month;
   	if(day>=0 && day<=9)
   	   day = "0" + day;
   h1.innerHTML = d.getFullYear() +"-"+ month +"-"+ day;
   alert("p2");
}

p3.onclick = function() {
	document.getElementById("parent").classList.add("fn-active");
	alert("p3");   
}

p4.onclick = function() {
	p8.remove();
	alert("p4");
}

p5.onclick = function() {
    window.open("https://www.taobao.com/");  
    alert("p5");
}

p6.onclick = function() {
   var para=document.createElement("li");
   var node=document.createTextNode("p9");
       para.appendChild(node);
   var element=document.getElementById("parent");
       element.appendChild(para); 
   para.onclick = function() {
      alert("p9");
   }
   alert("p6");
}

p7.onclick = function() {
   document.getElementById("div1").style.width = window.screen.width; 
   alert("p7");
} 

p8.onclick = function() {
   alert("p8");
} 
