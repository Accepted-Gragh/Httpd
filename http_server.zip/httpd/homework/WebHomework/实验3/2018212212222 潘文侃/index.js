document.querySelector('.m-box ul').addEventListener('click', function (e) {
    var node = e.target;
    if (node && node.nodeName == 'LI') {
        alert(node.innerHTML);
        switch (node.innerHTML) {
            case 'p1':
                node.style.color = 'red';
                break;
            case 'p2':
                var date = document.querySelector(".m-box h1");
                var time = new Date();
                date.innerHTML = time.getFullYear() + '-' + time.getMonth() + '-' + time.getHours();
                break;
            case 'p3':
                node.setAttribute('class', node.getAttribute('class') + ' fn-active');
                break;
            case 'p4':
                node.parentNode.removeChild(node.parentNode.children[7]);
                break;
            case 'p5':
                window.open('https://taobao.com');
                break;
            case 'p6':
                liNode = document.createElement('li');
                liNode.className = 'm-item';
                liNode.innerHTML = 'p9';
                node.parentNode.appendChild(liNode);
                break;
        }
    }
});


// var p = document.querySelectorAll(".m-box .m-item");

// // p[0].addEventListener('click', function () {
// //     this.style.color = 'red';
// // })

// // p[1].addEventListener('click', function () {
// //     var date = document.querySelector(".m-box h1");
// //     var time = new Date();
// //     date.innerHTML = time.getFullYear() + '-' + time.getMonth() + '-' + time.getHours();
// // })

// // p[2].addEventListener('click', function () {
// //     this.setAttribute('class', this.getAttribute('class') + ' fn-active');
// // })

// // p[3].addEventListener('click', function () {
// //     this.parentNode.removeChild(p[7]);
// // })

// // p[4].addEventListener('click', function () {
// //     window.open('https://taobao.com');
// // })

// // p[5].addEventListener('click', function () {
// //     liNode = document.createElement('li');
// //     liNode.className = 'm-item';
// //     liNode.innerHTML = 'p9';
// //     this.parentNode.appendChild(liNode);
// // })

// // for (let i = 0; i < p.length; i++) {
// //     p[i].addEventListener('click', function () {
// //         alert(i + 1);
// //     })
// // }