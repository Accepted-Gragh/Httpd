document.querySelector('.m-box ').addEventListener('click', function (e) {
    //点击li对象, 弹出 alert 对话框显示当前点击 li 的序号;
    if (e.target && e.target.nodeName == "LI") {
        alert(e.target.innerHTML);
    }
    //点击p1对象,其字体颜色变成红色;
    if (e.target.innerHTML == "p1") {
        e.target.style.color = 'red';
    }
    //点击p2对象,将h1的内容变成当前的日期,其格式为 yyyy-mm-dd ;
    if (e.target.innerHTML == "p2") {
        var d = new Date();
        var month = d.getMonth() + 1;
        document.querySelector(".m-box h1").innerHTML = d.getFullYear() + '-' + month + '-' + d.getDate();
    }
    //月份从0开始所以真实月份要加一
    //点击p3对象,将其父对象的li元素增加 fn-active 类;
    if (e.target.innerHTML == "p3") {
        document.querySelector(".m-box p2").classList.add("fn-active");
    }
    //点击p4对象,删除表格的p8元素;
    if (e.target.innerHTML == "p4") {
        var ul = document.querySelector(".m-box").querySelectorAll("li");
        ul[7].remove();
    }
    //点击p5对象,打开一个新窗口,里面显示淘宝主页;
    if (e.target.innerHTML == "p5") {
        window.open('https://taobao.com');
    }
    //点击p6对象,在 ul 的最后添加一个 li 元素，其内容是 p9;
    if (e.target.innerHTML == "p6") {
        var p9 = document.createElement('li');
        p9.className = 'm-item';
        p9.innerHTML = 'p9';
        e.target.parentNode.appendChild(p9);
    }

});
