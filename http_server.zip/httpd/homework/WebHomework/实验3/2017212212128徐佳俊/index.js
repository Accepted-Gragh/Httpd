var list = document.getElementsByClassName('m-item');
list[0].addEventListener("click",function (e) {
	this.style.color="red";
	alert("p1");
});
list[1].addEventListener("click",function (e) {
	var date = new Date();
    var format_date = date.getDate();
    var format_month = date.getMonth() + 1; 
    var format_year = date.getFullYear();
    String(format_month).length < 2 ? (format_month = "0" + format_month): format_month;
    String(format_date).length < 2 ? (format_date = "0" + format_date): format_date;
    var yyyyMMdd = format_year + "-" + format_month +"-"+ format_date;
	list[0].innerHTML=yyyyMMdd;
	alert("p2");
});
list[2].addEventListener("click",function (e) {
	this.classList.add("fn-active");
	alert("p3");
});
list[3].addEventListener("click",function (e) {
	list[7].remove();
	alert("p4");
});
list[4].addEventListener("click",function (e) {
	window.open("https://www.taobao.com/");
	alert("p5");
});
list[5].addEventListener("click",function (e) {
	var li9=document.createElement('li');
	li9.classList.add("m-item");
	li9.innerHTML='p9';
	li9.addEventListener("click",function (e) {
		alert("p9");
	});
	document.getElementById('Oul').appendChild(li9);
	alert("p6");
});
list[6].addEventListener("click",function (e) {
	alert("p7");
});
list[7].addEventListener("click",function (e) {
	alert("p8");
});
