document.getElementById("01").onclick=function(){
	this.style.color="red";
}

document.getElementById("02").onclick=function(){
	const time =new Date();
	const year =time.getFullYear();
	const month =time.getMonth()+1>12?time.getMonth()-11:time.getMonth()+1;
	const day =time.getDate();
	document.getElementById("02").innerHTML=year+"-"+month+"-"+day;
}

document.getElementById("03").onclick=function(){
	tbl.insertRow(-1);
}

document.getElementById("04").onclick=function(){
  const parent=document.getElementById("r2");
  const child1=document.getElementById("03");
  const child2=document.getElementById("04");
  parent.removeChild(child1);
  parent.removeChild(child2);
}

document.getElementById("05").onclick=function(){
        x=event.clientX
        y=event.clientY
        alert("X 坐标: " + x + ", Y 坐标: " + y)    
}

document.getElementById("06").onclick=function(){
	window.open("http://www.taobao.com");
}