
let list = document.querySelectorAll('.m-item');
let box = document.querySelector('.m-box');


box.addEventListener("click", e => {
  if (e.target && e.target.nodeName === "LI") {
    for (let i = 0, len = lis.length; i < len; i++) {
      if (e.target === lis[i]) {
      }
    }
  }
});


window.onload = function() {
	list[0].onclick = function(e) {
		list[0].style.color = "red";
		alert("NUMBER: 1")
	};

	list[1].onclick = function(e) {
		let date = new Date();
		let newdate = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
		box.childNodes[1].innerHTML = newdate;
		alert("NUMBER: 2")
	};

	list[2].onclick = function(e) {
		list[2].classList.add("fn-active");
		alert("NUMBER: 3")
	};

	list[3].onclick = function(e) {
		list[3].parentNode.removeChild(list[7]);
		alert("NUMBER: 4")
	};


	list[4].onclick = function(e) {
		window.open("https://www.taobao.com/");
		alert("NUMBER: 5")
	};

	list[5].onclick = function(e) {
		let para = document.createElement('li');
		let node = document.createTextNode('p9');
		para.appendChild(node);
		para.classList.add('m-item');
		list[5].parentNode.appendChild(para);
		alert("NUMBER: 6")
	};

}

 