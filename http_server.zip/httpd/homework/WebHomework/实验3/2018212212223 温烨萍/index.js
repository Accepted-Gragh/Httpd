/**
 * 
 * @authors Your Name (you@example.org)
 * @date    2020-03-12 16:04:28
 * @version $Id$
 */

var p = document.querySelectorAll('.m-item');
var li1 = document.getElementsByTagName('li');

var parent = document.getElementsByTagName("ul")

var today = new Date();
p[0].onclick=function(){
	this.style.color="red";
	alert("p1");
}

p[1].onclick = function(){
	this.innerHTML=today.getFullYear()+"-"+today.getMonth()+"-"+today.getDay()
	alert("p2");
}

p[2].onclick = function(){
	var para0=document.createElement("li")
	parent[0].appendChild(para0)
	para0.className='fn-active'

	alert("p3");

}

p[3].onclick = function(){
	p[7].parentNode.removeChild(p[7]);
	alert("p4");

}

p[4].onclick = function(){
	window.open("https://www.taobao.com/")
	alert("p5");
}

p[5].onclick = function(){
	var para=document.createElement("li");
	var node=document.createTextNode("p9");
	para.appendChild(node);
	parent[0].appendChild(para);
	alert("p6");
}

p[6].onclick = function(){
	var div1=document.getElementsByClassName("m-box")
	div1[0].style.width=screen.availWidth
	alert("p7")
}

p[7].onclick = function(){
	alert("p8")
}



