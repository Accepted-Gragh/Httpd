/**
 * 
 * @authors Your Name (you@example.org)
 * @date    2020-03-12 15:35:13
 * @version $Id$
 */
 var d = new Date();
     year = d.getFullYear(),
     month = d.getMonth()+1,
     date = d.getDate();
 var para=document.createElement("li"),
     node=document.createTextNode("p9");

document.getElementById("p1").onclick=function(e)
{
	p1.style.color="red";
}
document.getElementById("p2").onclick=function(e)
{
	h1.innerHTML=year+"--"+month+"--"+date;
}
document.getElementById("p3").onclick=function(e)
{
	p1.className+='fn-active';
	p2.className+='fn-active';
	p3.className+='fn-active';
	p4.className+='fn-active';
	p5.className+='fn-active';
	p6.className+='fn-active';
	p7.className+='fn-active';
	p8.className+='fn-active';
}
document.getElementById("p4").onclick=function(e)
{
	u1.removeChild(p8);
}
document.getElementById("p5").onclick=function(e)
{
	window.open("https://uland.taobao.com");
}
document.getElementById("p6").onclick=function(e)
{
    para.appendChild(node);
    u1.appendChild(para);
    para.className="m-item";
    para.id="p9";
}
document.getElementById("u1").onclick=function(e)
{
	 if(e.target.id=="p1")
	{
		alert(1);
	}
	else if(e.target.id=="p2")
	{
		alert(2);
	}
	else if(e.target.id=="p3")
	{
		alert(3);
	}
	else if(e.target.id=="p4")
	{
		alert(4);
	}
	else if(e.target.id=="p5")
	{
		alert(5);
	}
	else if(e.target.id=="p6")
	{
		alert(6);
	}
	else if(e.target.id=="p7")
	{
		alert(7);
	}
	else if(e.target.id=="p8")
	{
		alert(8);
	}
	else if(e.target.id=="p9")
	{
		alert(9);
	}
}
document.getElementById("p7").onclick=function(e)
{
	window.resizeTo(screen.availWidth,document.body.clientHeight);
}
