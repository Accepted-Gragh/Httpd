var li=document.getElementsByClassName("m-item");
var h1= document.getElementsByTagName("h1")[0];
  var oul=document.getElementsByTagName("ul")[0];
  var lis=oul.getElementsByTagName("li");


li[0].onclick=function(){
this.style.color="red";
}
   function getNowFormatDate() {
        var date = new Date();
        var seperator1 = "-";
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        var currentdate = year + seperator1 + month + seperator1 + strDate;
        return currentdate;
    }
li[1].onclick=function(){
   h1.innerHTML=getNowFormatDate();
}
li[2].onclick=function(){
    this.className+=' fn-active';
}
li[3].onclick=function(){
    oul.removeChild(lis[7]);
}
li[4].onclick=function(){
    window.open("https://www.tmall.com");
}
li[5].onclick=function(){

        //1. 创建1个li标签
        var createLi = document.createElement("li");
        //2. 创建文本
        var text = document.createTextNode("p9");
        //3. 把创建的文本加入到创建的li标签中
        createLi.appendChild(text)
        //4. 把创建的li加入到ul中
        oul.appendChild(createLi)

}
li[6].onclick=function(){

    alert(li[6].innerHTML);  
}
li[7].onclick=function(){
    
}