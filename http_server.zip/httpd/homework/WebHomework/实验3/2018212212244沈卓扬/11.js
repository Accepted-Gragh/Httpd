function Color() {
	document.getElementById("1").style.color="red";
}
function Data(){
	var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth()+1;
    var day = date.getDate();
    document.getElementById("d").innerHTML=year+"-"+month+"-"+day;  
}
function Addclass(){
	var obj = document.getElementById("3");
        obj.classList.add("fn-active");
}
function Delete(){
	document.getElementById("8").innerHTML="";
}
function Open(){
	window.open("https://www.taobao.com/" );
}
function Creaitve(){
        var u = document.getElementById("u");
        var newli = document.createElement("li");
        var p = document.createTextNode("p9");
        newli.appendChild(p);
        u.appendChild(newli);
      }
function index(obj){
        var n = obj.id;
        alert(n);
}
document.getElementById("u").addEventListener("click",function(e) {
if(e.target && e.target.nodeName == "LI") {
        index(e.target);
}
});