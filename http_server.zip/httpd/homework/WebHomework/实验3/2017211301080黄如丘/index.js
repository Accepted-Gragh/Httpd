document.getElementById("l1").onclick=function(){
	this.style.color="red";
	alert("1");
}
document.getElementById("l2").onclick=function(){
	var today=new Date();
	var h=today.getFullYear();
	var m=today.getMonth()+1;
	if(m>12) m=m-12;
	var s=today.getDate();
	document.getElementById("h1").innerHTML=h+"-"+m+"-"+s;
	alert("2");
}
document.getElementById("l3").onclick=function(){
	document.getElementById("l3").parentNode.classList.add("fn-active");
	alert("3");
}
document.getElementById("l4").onclick=function(){
  var parent=document.getElementById("par");
  var child=document.getElementById("l8");
  parent.removeChild(child);
  alert("4");
}
document.getElementById("l5").onclick=function(){
	window.open("http://www.taobao.com");
	alert("5");
}
document.getElementById("l6").onclick=function(){
	var elem_li = document.createElement('li'); 
    elem_li.innerHTML = "p9"; 
    document.getElementById('par').appendChild(elem_li);
    alert("6");
}
document.getElementById("l7").onclick=function(){
	window.document.body.offsetWidth;
	document.getElementById('div1').style.width ="960px";
	alert("7");
}