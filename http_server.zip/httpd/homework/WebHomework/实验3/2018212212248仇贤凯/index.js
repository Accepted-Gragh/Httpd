  var oUl = document.getElementById("ul");
  var aLi = oUl.getElementsByTagName("li");
  var ah=document.getElementById("h1");
  var data=new Date();

  aLi[0].onmousedown=function(e){
  	this.style.color="red";
  	alert("1");
  }
  aLi[1].onmousedown=function(e){
  	var month=data.getMonth()+1
  	ah.innerHTML=data.getFullYear()+"-"+month+"-"+data.getDate();
  	alert("2");
  }
  aLi[2].onclick=function(){
    this.className+=' fn-active';
    alert("3");
}
  aLi[3].onclick=function(e){
	oUl.removeChild(aLi[7]);
    };
   aLi[4].onmousedown=function(e){
  	window.open("https://www.taobao.com");
  	alert("5");
  }
  aLi[5].onmousedown=function(){
    var p9 = document.createElement("li");
    var text = document.createTextNode("p9");
    p9.appendChild(text);
    oUl.appendChild(p9);
    alert("6");
  }
   aLi[6].onmousedown=function(e){
  	alert("7");
  }
  aLi[7].onmousedown=function(e){
  	alert("8");
  }
