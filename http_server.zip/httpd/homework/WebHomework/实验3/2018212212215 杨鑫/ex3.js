var p1 = document.getElementsByClassName('m-item')[0]
var p2 = document.getElementsByClassName('m-item')[1]
var p3 = document.getElementsByClassName('m-item')[2]
var p4 = document.getElementsByClassName('m-item')[3]
var p5 = document.getElementsByClassName('m-item')[4]
var p6 = document.getElementsByClassName('m-item')[5]
var p7 = document.getElementsByClassName('m-item')[6]
var p8 = document.getElementsByClassName('m-item')[7]
var date = document.getElementById('date')
var list =document.getElementsByTagName('li');
var box = document.getElementsByClassName('m-box')[0]

function changeColor() {
	p1.style.color = 'red'
}

function getDate() {
	var d = new Date()
	var year = d.getFullYear()
    var month = d.getMonth() + 1
    var day = d.getDate()
    date.innerText = year + '-' + month + '-' + day
}

function addClass(e) {
    e.parentNode.className = 'fn-active'
}

function remove(e) {
    if (p8) {
        e.parentNode.removeChild(p8)
    }
}

function addLi(e) {
    var li = document.createElement('li')
    li.innerHTML = 'p9'
    e.parentNode.appendChild(li)
}

for(var i=0;i<list.length;i++){
    list[i].index=i;
    list[i].addEventListener("click",function () {
        alert(this.index+1);
    })
}

function vwvh() {
    box.style.width='100vw'
    box.style.height='100vh'
}