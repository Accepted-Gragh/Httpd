/**
 * 
 * @authors Your Name (you@example.org)
 * @date    2020-03-16 09:53:47
 * @version $Id$
 */
 function getdate() {
 	var separate = '-';
 	var date = new Date();
 	var year = date.getFullYear();
 	var month = date.getMonth()+1; //Date.getMonth返回值是0(1月)~11(12月)之间的一个整数,用0表示一年中的第一个月。
 	var day = date.getDate();
 	if(month >= 1 && month <= 9){
 		month = "0" + month;
 	}
 	if(day >= 0 && day <= 9){
 		day = "0" + day;
 	}
 	var currentDay = year + separate + month + separate + day;
 	return currentDay;
 }

var li = document.getElementsByClassName('m-item');
	for(var i = 0; i < li.length; i++){
		(function(e){
			li[e].onclick = function(){
				alert(e);
			}
		}(i))
	}
	li[0].onclick = function(){
		this.style.color = "red";
		alert(0);
	}
	li[1].onclick = function(){
		var h1 = document.getElementsByTagName("h1")[0];
		h1.innerHTML = getdate();
		alert(1);
	}
	li[2].onclick = function(){
		this.className+="fn-active";
		alert(2);
	}
	li[3].onclick = function(){
		//li[3].parentNode.removeChild(li[7]);
		document.getElementsByTagName('ul')[0].removeChild(document.getElementsByTagName('ul')[0].getElementsByTagName('li')[7]);
		//document.getElementsByTagName根据标签获取元素 取得的是一个数组 包含所有指定标签的集合 其中document.getElementsByTagName('ul')[0]表示页面上的第1个ul标签 removeChild方法用于移除子元素 参数为需要移除的元素
		alert(3);
	}
	li[4].onclick = function(){
		window.open("https://www.taobao.com/");
		alert(4);
	}
	li[5].onclick = function(){
		var para = document.createElement("li");
		var node= document.createTextNode("p9");
		para.appendChild(node);
		//li[6].appendChild(para);
		document.getElementsByTagName('ul')[0].appendChild(para);
		alert(5);
	}
	li[7].onclick = function(){
		alert(7);
	}


