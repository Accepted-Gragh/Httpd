var oUl = document.getElementById("u1");
var aLi = oUl.getElementsByTagName("li");
var h1 = document.getElementById("h1");
aLi[0].onclick=function(){
    aLi[0].style.color="red";
}

aLi[1].onclick=function(){
	var date = new Date();
	var nowMonth = date.getMonth() + 1;
    var strDate = date.getDate();
    var seperator = "-";
    if (nowMonth >= 1 && nowMonth <= 9) {
       nowMonth = "0" + nowMonth;
    }
    if (strDate >= 0 && strDate <= 9) {
       strDate = "0" + strDate;
    }
    var nowDate = date.getFullYear() + seperator + nowMonth + seperator + strDate;
    h1.innerHTML=nowDate;
}

aLi[2].onclick=function(){
	for(var i=0; i<aLi.length; i++){
		aLi[i].className="fn-active";
    }
}

aLi[3].onclick=function(){
    aLi[7].remove();
}

aLi[4].onclick=function(){
    window.open("https://www.taobao.com");
}

aLi[5].onclick=function(){
	var l9 = document.createElement("li");
    l9.innerHTML = "p9";
    l9.className = "fn-active";
    oUl.appendChild(l9);
}

window.onload = function(){
  for(var i=0; i<aLi.length; i++){
    aLi[i].onmouseup = function(){
      alert(this.innerHTML);
    }
  }
}