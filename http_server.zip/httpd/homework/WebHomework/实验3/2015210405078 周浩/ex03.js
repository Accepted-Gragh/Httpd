document.getElementById("p1").onclick=function() {
	this.style.color="red";
	alert("已点击p1对象,其字体颜色变成红色");
}

document.getElementById("p2").onclick=function() {
	var today=new Date();
	var h=today.getFullYear();
	var m=today.getMonth()+1;
	if(m>12) m=m-12;
	var s=today.getDate();
	document.getElementById("h1").innerHTML=h+"-"+m+"-"+s;
	alert("已点击p2对象,将h1的内容变成当前的日期2");
}

document.getElementById("p3").onclick=function() {
	document.getElementById("p3").parentNode.classList.add("fn-active");
	alert("已点击p3对象,将其父对象的li元素增加 fn-active 类");
}

document.getElementById("p4").onclick=function() {
  var parent=document.getElementById("par");
  var child=document.getElementById("p8");
  parent.removeChild(child);
  alert("已点击p4对象,删除表格的p8元素");
}

document.getElementById("p5").onclick=function() {
	alert("已点击p5对象，即将前往淘宝主页");
	window.open("http://www.taobao.com");
}

document.getElementById("p6").onclick=function() {
	var elem_li = document.createElement('li'); 
    elem_li.innerHTML = "p9"; 
    document.getElementById('par').appendChild(elem_li);
    alert("已点击p6对象,添加p9");
}

document.getElementById("p7").onclick=function() {
	window.document.body.offsetWidth;
	document.getElementById('div1').style.width ="960px";
	alert("已点击p7");
}