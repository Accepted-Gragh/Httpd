var ul=document.getElementsByTagName("ul");
var li=document.getElementsByClassName("m-item");

li[0].onclick=function(e){
	this.style.color='red';
	alert('1');
}

li[1].onclick=function(e){
	var h1=document.getElementsByTagName("h1")[0];
	h1.innerHTML=getTime();
	alert('2');
}

li[2].onclick=function(e){
	this.className+="fn-active";
	alert('3');
}

li[3].onclick=function(e){
	ul[0].removeChild(ul[0].getElementsByTagName('li')[7]);
	alert('4');
}

li[4].onclick=function(e){
	window.open("http://www.taobao.com");
	alert('5');
}

li[5].onclick=function(e){
	var p9 = document.createElement("li");
    var text = document.createTextNode("p9");
    p9.appendChild(text);
    ul[0].appendChild(p9);
    alert("6");
}

li[6].onclick=function(e){
	alert('7');
}

li[7].onclick=function(e){
	alert('8');
}

function getTime(){
	var date=new Date();
	var year=date.getFullYear();
	var month=date.getMonth()+1;
	var day=date.getDate();
	if(month>0&&month<10)
		month="0"+month;
	if(day>0&&day<10)
		day="0"+day;
	var newday=year+"-"+month+"-"+day;
	return newday;
}