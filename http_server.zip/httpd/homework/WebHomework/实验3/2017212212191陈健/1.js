var p = document.getElementById("m-li");
var h = document.getElementById("H1");
var Li=document.getElementsByTagName('li');

Li[0].addEventListener("click",function(e){
	this.style.color="red";
});

Li[1].addEventListener("click",function(e){
	var date = new Date();
    var a = "-";
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
        }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
        }
    var currentdate = year + a + month + a + strDate;
    h.innerHTML=currentdate;
})

Li[2].addEventListener("click",function(e){
    this.className+=' fn-active';
    for (var index = 0; index < Li.length; index++) {
      Li[index].className+=' fn-active';
    }
});

Li[3].addEventListener("click",function(e){
	p.removeChild(Li[7]);
});

Li[4].addEventListener("click",function(e){
	window.open("https://www.taobao.com/");
});

Li[5].addEventListener("click",function(e){
	var p9=document.createElement("li");
	var t=document.createTextNode("p9");
	p9.appendChild(t);
	p.appendChild(p9);
});

window.onload=function(){
  for (var index = 0; index < Li.length; index++) {
    (function (index) {
      Li[index].onclick = function () {
        alert(index+1);
      };
    })(index);
  }
}