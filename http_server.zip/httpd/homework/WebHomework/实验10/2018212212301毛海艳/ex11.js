/**
 * 
 * @authors hy
 * @date    2020-05-12 09:57:28
 * @version 1.0
 */
$(init)
function init(argument) {
	$(".nav>li").click(function() {
		let $sub = $(this).children('.sub');
		$sub.slideToggle(1000);
		let otherSub = $(this).siblings().children(".sub");
		otherSub.slideUp(1000);
		$(this).toggleClass("current");
		$(this).siblings().removeClass('current');
	});
}