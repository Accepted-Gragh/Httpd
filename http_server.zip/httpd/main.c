#include "include/microhttpd.h"
#include <string.h>
#include <stdio.h> 
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
 
#define PAGE "<html><head><title>demo</title>"\
             "</head><body>libmicrohttpd demo</body></html>"
#define get_order_max_len 10000


static enum MHD_Result
ahc_echo(void * cls,
         struct MHD_Connection * connection,
         const char * url,
         const char * method,
         const char * version,
         const char * upload_data,
         size_t * upload_data_size,
         void ** ptr) {
  static int dummy;
  const char * page = cls;
  struct MHD_Response * response;
  int ret;
	// 非 get 请求
  if (0 != strcmp(method, "GET"))
    return MHD_NO; /* unexpected method */
	// 首次数据包只有 header， 不发送响应数据包
  if (&dummy != *ptr)
    {
      /* The first time only the headers are valid,
         do not respond in the first round... */
      *ptr = &dummy;
      return MHD_YES;
    }
	// get 请求不允许上传数据
  if (0 != *upload_data_size)
    return MHD_NO; /* upload data in a GET!? */
	// 清空内容地址
  *ptr = NULL; /* clear context pointer */

	
  response = MHD_create_response_from_buffer (strlen(page),
                                              (void*) page,
  					      MHD_RESPMEM_PERSISTENT);

  ret = MHD_queue_response(connection,
			   MHD_HTTP_OK,
			   response);
  MHD_destroy_response(response);
  return ret;
}

//返回本地主机名
void checkHostName(int hostname){
    if(hostname == -1){
        perror("gethostname");
        exit(1);
    }
}

//返回主机对应的信息到主机名
void checkHostEntry(struct hostent *hostentry){
    if(hostentry == NULL){
        perror("gethostbyname");
        exit(1);
    }
}

//将Ipv4地址格式转化为点分十进制
void checkIPbuffer(char *IPbuffer){
    if(NULL == IPbuffer){
        perror("inet_ntoa");
        exit(1);
    }
}


int main(int argc,char ** argv) 
{
  struct MHD_Daemon *d;
  if (argc != 2) {
	// 用户没有输入端口号
    printf("%s PORT\n",
	   argv[0]);
    return 1;
  }
  d = MHD_start_daemon(MHD_USE_THREAD_PER_CONNECTION,
		       atoi(argv[1]),
		       NULL,
		       NULL,
		       &ahc_echo,
		       PAGE,
		       MHD_OPTION_END);
			//服务器开始运行
  if (d == NULL)
    return 1;
  char hostbuffer[256];
  char *IPbuffer;
  struct hostent *host_entry;
  int hostname;
  //接收主机名
  hostname = gethostname(hostbuffer, sizeof(hostbuffer));
  checkHostName(hostname);
  //接收主机信息
  host_entry = gethostbyname(hostbuffer);
  checkHostEntry(host_entry);
  //转换网络地址
  IPbuffer = inet_ntoa(*((struct in_addr*)host_entry->h_addr_list[0]));
  printf("Hostname: %s\n", hostbuffer);
  printf("Host IP: %s\n", IPbuffer);
  char in_order[get_order_max_len];
  char get_order[get_order_max_len];
  memset(in_order,0,sizeof(in_order)); //生成所需指令
  strcat(in_order,"http://");
  strcat(in_order,IPbuffer);
  strcat(in_order,"/analysisRet");
  printf("get order is : %s\n",in_order);


	while(1)
	{
		scanf("%s",get_order);
		if(strcmp(get_order,in_order) == 0)
		{		
			printf("分析数据\n");
		}
		else if(strcmp(get_order,"end") == 0) //输入end结束服务器
		{
			break;
		}
	}
	MHD_stop_daemon(d);
//  (void) getc (stdin);
//  MHD_stop_daemon(d);
  return 0;
}
























